
import 'package:flutter/material.dart';
import 'cloud_sync_settings_page.dart';

void main() {
  runApp(MaterialApp(
    home: CloudSyncSettingsPage(),
    debugShowCheckedModeBanner: false,
  ));
}
