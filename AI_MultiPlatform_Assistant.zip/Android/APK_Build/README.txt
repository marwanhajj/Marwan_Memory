To build the APK manually:
1. Open Android Studio.
2. Create a new Flutter project.
3. Replace `lib/main.dart` with the provided `main.dart`.
4. Add cloud_sync_settings_page.dart in the `lib/` folder.
5. Run `flutter pub get` to fetch dependencies.
6. Click on 'Build > Build Bundle(s) / APK(s) > Build APK(s)'.
7. The APK will be available in the `build/app/outputs/flutter-apk/` directory.
