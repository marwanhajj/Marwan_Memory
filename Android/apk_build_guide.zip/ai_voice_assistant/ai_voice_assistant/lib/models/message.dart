class Message {
  final String text;
  final bool isFromUser;
  final DateTime timestamp;
  final bool isVoiceMessage;

  Message({
    required this.text,
    required this.isFromUser,
    required this.timestamp,
    this.isVoiceMessage = false,
  });
}
