To build and run this Flutter project on macOS:
1. Ensure Flutter SDK is installed and configured.
2. Navigate to this folder in terminal.
3. Run: flutter create .
4. Replace `lib/main.dart` with the provided one.
5. Place `cloud_sync_settings_page.dart` inside `lib/`.
6. Run: flutter pub get
7. For desktop platforms, run: flutter run -d macos
